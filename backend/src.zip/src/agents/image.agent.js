import { Agent } from "@openai/agents";
import { imagePrompt } from "../prompts/image.prompt.js";
import { generateImage } from "../providers/image.provider.js";

export const imageAgent = new Agent({
  name: "Image Agent",
  instructions: imagePrompt,
  handoffDescription: "Handles image-generation requests.",
});

export async function generateImageResponse({
  history = [],
  userPrompt,
  useCase,
  mediaUrl,
}) {
  const imageUrl = await generateImage({
    userPrompt,
    useCase,
    history,
    mediaUrl,
  });

  return {
    type: "image",
    data: {
      imageUrl,
      prompt: userPrompt,
    },
  };
}
