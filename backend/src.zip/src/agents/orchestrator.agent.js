import { Agent, Runner } from "@openai/agents";
import { orchestratorPrompt } from "../prompts/orchestrator.prompt.js";
import { imageAgent } from "./image.agent.js";
import { textAgent } from "./text.agent.js";

export const orchestrator = new Agent({
  name: "Orchestrator",
  instructions: orchestratorPrompt,
  handoffs: [imageAgent, textAgent],
  handoffDescription: "Routes requests to the appropriate specialist agent.",
});

const runner = new Runner();

function parseIntent(output) {
  if (!output) {
    return "text";
  }

  if (typeof output === "object") {
    return output.intent === "image" ? "image" : "text";
  }

  const cleaned = String(output).trim();
  const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      return parsed.intent === "image" ? "image" : "text";
    } catch {
      // fall through
    }
  }

  return cleaned.toLowerCase().includes("image") ? "image" : "text";
}

export async function orchestrateRequest(userPrompt, useCase = "home") {
  const result = await runner.run(orchestrator, userPrompt);

  return {
    intent: parseIntent(result?.finalOutput),
    useCase,
  };
}
