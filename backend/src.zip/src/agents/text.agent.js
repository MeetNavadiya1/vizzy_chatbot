import { Agent } from "@openai/agents";
import { textPrompt } from "../prompts/text.prompt.js";
import { generateText } from "../providers/llm.provider.js";

export const textAgent = new Agent({
  name: "Text Agent",
  instructions: textPrompt,
  handoffDescription: "Handles writing and copy requests.",
});

export async function generateTextResponse({
  history = [],
  userPrompt,
  useCase,
}) {
  const content = await generateText({ userPrompt, useCase, history });

  return {
    type: "text",
    data: {
      content,
    },
  };
}
