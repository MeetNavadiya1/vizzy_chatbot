export const INTENTS = {
  IMAGE: "image",
  TEXT: "text",
};

export const DEFAULT_MODE = "home";
