import mongoose from "mongoose";
import { env } from "./env.js";

export const connectDB = async () => {
  if (!env.MONGO_URI) {
    console.info(
      "Database connection skipped; using local file-backed conversation storage.",
    );
    return;
  }

  try {
    await mongoose.connect(env.MONGO_URI);
    console.info("Database connected successfully.");
  } catch (error) {
    console.error("Database connection failed.", error.message);
    throw error;
  }
};

export const closeDB = async () => {
  if (!env.MONGO_URI) {
    console.info("Database shutdown skipped.");
    return;
  }

  await mongoose.disconnect();
};
