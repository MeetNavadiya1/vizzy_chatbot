import { Runner } from "@openai/agents";
import { textAgent } from "../agents/text.agent.js";

const runner = new Runner();

export async function generateText({ userPrompt, useCase, history = [] }) {
  const normalizedUseCase = (useCase || "home").toLowerCase();
  const historyText =
    history.length > 0
      ? `\nConversation history:\n${history.map((item) => `${item.role}: ${item.content}`).join("\n")}`
      : "";

  const agentInput = `${userPrompt}${historyText}\nUse case: ${normalizedUseCase}`;

  try {
    const result = await runner.run(textAgent, agentInput);
    const output = result?.finalOutput;

    if (typeof output === "string" && output.trim()) {
      return output.trim();
    }

    if (output && typeof output === "object") {
      return String(output?.content || output?.text || "").trim();
    }
  } catch (error) {
    console.warn(
      "OpenAI text agent run failed, falling back to local response.",
      error.message,
    );
  }

  const fallback =
    normalizedUseCase === "business"
      ? `Professional ${normalizedUseCase} copy tailored to your request: ${userPrompt}`
      : `A polished ${normalizedUseCase} response for your request: ${userPrompt}`;

  return fallback;
}
