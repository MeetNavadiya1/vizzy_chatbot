import { Runner } from "@openai/agents";
import { imageAgent } from "../agents/image.agent.js";

const runner = new Runner();

export async function generateImage({
  userPrompt,
  useCase,
  history = [],
  mediaUrl,
}) {
  const normalizedUseCase = (useCase || "home").toLowerCase();
  const historyText =
    history.length > 0
      ? `\nConversation history:\n${history.map((item) => `${item.role}: ${item.content}`).join("\n")}`
      : "";
  const attachmentText = mediaUrl
    ? `\nUploaded attachment reference:\n${mediaUrl}`
    : "";

  const agentInput = `${userPrompt}${historyText}${attachmentText}\nUse case: ${normalizedUseCase}`;

  try {
    const result = await runner.run(imageAgent, agentInput);
    const output = result?.finalOutput;

    if (typeof output === "string" && output.trim()) {
      return output.trim();
    }

    if (output && typeof output === "object") {
      return String(
        output?.content || output?.text || output?.prompt || "",
      ).trim();
    }
  } catch (error) {
    console.warn("OpenAI image agent run failed.", error.message);
  }

  return "";
}
