import { orchestrateRequest } from "../agents/orchestrator.agent.js";
import { generateImageResponse } from "../agents/image.agent.js";
import { generateTextResponse } from "../agents/text.agent.js";
import { getConversationHistory } from "./conversation.service.js";
import { INTENTS } from "../types/ai.types.js";

export async function runAiWorkflow({
  conversationId,
  userPrompt,
  useCase,
  mediaUrl,
}) {
  const normalizedUseCase = (useCase || "home").toLowerCase();
  const history = await getConversationHistory(conversationId);
  const routing = await orchestrateRequest(userPrompt);

  const userMessage = {
    role: "user",
    content: userPrompt,
    mediaUrl: mediaUrl || null,
  };

  let assistantMessage;

  if (routing.intent === INTENTS.IMAGE) {
    const imageResult = await generateImageResponse({
      history,
      userPrompt,
      useCase: normalizedUseCase,
      mediaUrl,
    });
    assistantMessage = {
      role: "assistant",
      content: imageResult.data.prompt,
      mediaUrl: imageResult.data.imageUrl || null,
    };
  } else {
    const textResult = await generateTextResponse({
      history,
      userPrompt,
      useCase: normalizedUseCase,
      mediaUrl,
    });
    assistantMessage = {
      role: "assistant",
      content: textResult.data.content,
      mediaUrl: null,
    };
  }

  return {
    type: routing.intent === INTENTS.IMAGE ? "image" : "text",
    conversationId,
    userMessage,
    assistantMessage,
    routing,
  };
}
